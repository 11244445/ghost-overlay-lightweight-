# GhostBar game test checklist

Run every block for each game/mode. `ghostbar.log` (`%AppData%\GhostBar\ghostbar.log`) records objective evidence for
most checks: look for the quoted lines.

## Before you start

* Start GhostBar (tray ghost icon visible). The replay buffer should be on (Clipping widget → toggle).
* Idle RAM command (PowerShell), used in check 5:
  ```powershell
  $p = Get-Process GhostBar; "{0:N1} MB private, {1:N1} MB working set" -f ($p.PrivateMemorySize64/1MB), ($p.WorkingSet64/1MB)
  ```

## The five checks (per game/mode)

1. **No minimize**: in a match or the firing range, press **Win+J**. The game must stay visible behind the overlay (with
   the dim) and must not minimize, flicker to the desktop or change resolution.
   Log: `overlay opened in X ms over '<game>' (focus taken, exclusive false, view-only false)`. X should be < 100.
2. **Focus returns**: press **Esc** (or Win+J again). The overlay disappears and the game has focus.
   Log: `overlay closed, focus returned to game: yes`.
3. **Input works immediately**: without clicking, move the mouse (camera turns), then press W and fire. All three must
   work on the first try. Repeat 5× quickly (open/close/aim).
4. **Overlay not in clips**: open the overlay, press **Alt+F10** while it's open, close it, wait 2 s, press Alt+F10
   again. Open both clips: neither may show the overlay or the "Clip saved" toast. Discord: stream your screen while
   opening the overlay; viewers must not see it.
5. **Idle RAM**: close the overlay, turn the replay buffer **off**, wait 10 s, run the RAM command.
   Target: **< 40 MB private** (dev machine: ~10.5 MB). With the buffer on, expect ≈ 50 MB plus the buffer estimate
   shown in the widget.

Also note: whether Win+J triggered anything in Windows (it must not), and whether the Start menu popped up after
releasing Win (it must not).

## Matrix

| Game | Display mode | 1 No minimize | 2 Focus back | 3 Input | 4 Not in clips | 5 Idle RAM | Notes |
|---|---|---|---|---|---|---|---|
| Valorant | Windowed Fullscreen | ☐ | ☐ | ☐ | ☐ | ☐ | Vanguard running |
| Valorant | Fullscreen | ☐ | ☐ | ☐ | ☐ | ☐ | See "exclusive" below |
| CS2 | Fullscreen Windowed | ☐ | ☐ | ☐ | ☐ | ☐ | |
| CS2 | Fullscreen | ☐ | ☐ | ☐ | ☐ | ☐ | Usually flip-model (behaves like borderless) |
| Fortnite | Windowed Fullscreen | ☐ | ☐ | ☐ | ☐ | ☐ | EAC/BattlEye |
| Fortnite | Fullscreen | ☐ | ☐ | ☐ | ☐ | ☐ | |
| GTA V Enhanced | Borderless | ☐ | ☐ | ☐ | ☐ | ☐ | BattlEye; installed on the dev PC |
| Any borderless game | Borderless | ☐ | ☐ | ☐ | ☐ | ☐ | |

### Exclusive fullscreen rows

Most modern DX11/DX12 "Fullscreen" modes are flip-model with Fullscreen Optimizations and behave like borderless: all
five checks should pass. If the game really is in **exclusive** fullscreen, the log says `exclusive true, view-only true`.
In that case the expected behaviour is:

* The first time, a toast suggests Borderless / Windowed Fullscreen.
* The overlay appears **view-only**: the game keeps focus and is not minimized, and the mouse/keyboard still drive the game.
* Check 2 then means: "game never lost focus".

If the game still minimizes in that mode, record it in the Notes column. Windows doesn't allow any separate window to
take focus over a true exclusive-mode swap chain without a mode switch. Only in-process hooks avoid that, and GhostBar
refuses to use them because of anti-cheat.

## Clip checks (once per GPU vendor)

* Alt+F10 with the overlay closed → toast "Clip saved – 60s" within about 1 s.
  Log: `clip saved (… s, … bytes) written in N ms` (dev machine: 296 ms for a 312 MB 4K clip).
* The clip plays in the Films & TV app/VLC with 2 audio tracks ("Game", "Mic"), and the clip starts cleanly with no
  grey or blocky first frames.
* Alt+F9 starts a recording (toast). Alt+F9 again → "Recording saved" and an `.mp4` (remuxed from the crash-safe `.mkv`).
* Mode "Auto-start with games": start a listed game → buffer starts (REPLAY dot turns red). Quit the game → it stops.
* Settings → Capture → change Resolution: the buffer restarts and the status line shows the new size.
  Dragging a slider such as Bitrate restarts the buffer only once, after you release the mouse.

## Editor / export checks

* In the Clipping widget, click ✂ on a clip. The Clip editor opens with a preview, 10 timeline thumbnails and keyframe
  ticks.
* Drag In/Out. The preview updates to the handle you released.
  "Save trimmed copy" → a `_trim.mp4` appears almost instantly. It plays and starts at most 1 s before In.
* ⇪ (or the preset "Discord (10 MB)") → Export. The plan line shows the resolution/fps/bitrate. The result must be
  **under 10 MB** and play in Discord's inline player. Copy (📋) and paste into a Discord message to confirm.
* "YouTube Shorts / TikTok": drag the crop box over the action, export, and check that the 9:16 file shows that area.
* Export while a game is running: there should be no stutter (Below Normal thread, GPU encoder).
* Headless check: `GhostBar.exe --export clip.mp4 discord10` prints the plan and the final size.

## Web / app / layout / HUD checks

* **Web tabs:** add the widget, log into Discord web (or Steam), and scroll down a page. Close the overlay, exit
  GhostBar from the tray, and start it again. The tabs, the login and the scroll position must all be back.
* **Suspension:** play a YouTube video in one tab and leave another tab idle, then close the overlay. The music keeps
  playing. In Task Manager, the idle tab's `msedgewebview2` processes should show ~0 % CPU (suspended).
* **Discard:** Settings → Web tabs → set "Discard idle tabs after" to 5 min. Close the overlay and wait 5 min. The
  Diagnostics widget's "Web views open" drops, and the tabs reload when you open the overlay again.
* **App window:** in the widget, + → pick Discord. A live preview appears. Click it and the real Discord window moves
  into the widget, usable and above the overlay. Clicking elsewhere on the overlay keeps Discord on top. Close the
  overlay: Discord goes back to exactly where it was, and the game has focus (log: `focus returned to game: yes`).
* **Layouts:** make a second layout and, with the game in front, enable "Use automatically for <game>.exe". The overlay
  must open with that layout in the game and with the general layout on the desktop.
* **HUD:** pin the System widget and set the opacity with the mouse wheel over the pin. Close the overlay: the System
  panel stays visible, the game keeps focus, and clicks go through to the game. Check the HUD is **not** in clips.
* **Visual regression without a game:** `GhostBar.exe --snapshot out.png` renders every widget offscreen.

## Lightweight checks

* **Idle**: with no game running, `Task Manager → GhostBar` shows ~10 MB and 0 % CPU, and Settings → Performance says
  "Idle · starts automatically when a game runs".
* **Auto-start**: start a listed game (or any borderless game). Within a few seconds the log shows
  `game detected: <exe>` and `replay buffer running`, the top bar shows **REPLAY**, and Task Manager's *Memory* column
  settles at roughly 7-16 MB while recording. Quit the game: the buffer stops and memory returns to ~10 MB.
* **Browsers don't trigger it**: a fullscreen YouTube video in Chrome/Edge must not start the buffer.
* **Profiles**: Clipping widget → Profile → *Lightest*. The buffer restarts at 720p30 and the RAM estimate drops.
* **Benchmark without a game**: `GhostBar.exe --bench-replay light 15` prints CPU, private bytes and the
  working set before and after trimming.

## New feature checks

* **Screenshot**: press Alt+F11 in a game. A toast says "Screenshot saved" and a PNG appears in
  `<clips folder>\Screenshots\<Game>\`. It must not contain the overlay or the toast.
* **After saving**: enable "Copy the clip to the clipboard" and "Also make: Discord 10 MB", save a clip with Alt+F10,
  then paste into Discord: the optimized (≤ 10 MB) copy arrives a few seconds later.
* **Per-app audio**: Settings → Clip audio → "Track 1: only selected apps", tick the game (and Discord). Play music in
  a browser while saving a clip: the music must be absent, the game and Discord present.
* **Now playing**: start Spotify or a YouTube video; the widget shows the title, cover and controls, and the buttons work.
* **Timer / Quick launch**: run a countdown, close the overlay and reopen it later (it kept counting); add an app and a
  link to Quick launch and click them.
* **Themes**: Settings → Appearance → Theme → *Light*, *Aurora*, *Ember*, *Graphite*; Interface size → 130 % on a 4K screen.
* **Visual regression without a game**: `GhostBar.exe --snapshot out.png light` (any theme name).
